@extends('admin.layouts.app')

@section('title', 'Kelola Galeri | Admin Pituwolu')

@section('content')
<div class="container mx-auto px-4 py-6">

    <!-- Header -->
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Galeri</h1>
        <a href="{{ route('admin.gallery.create') }}" class="btn btn-primary btn-sm">
            <span class="material-symbols-outlined text-base">add</span> Tambah
        </a>
    </div>

    <!-- Alert -->
    @if(session('success'))
    <div class="alert alert-success mb-4 text-sm">
        {{ session('success') }}
    </div>
    @endif

    @if($galleries->count() > 0)

    <!-- Grid -->
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">

        @foreach($galleries as $gallery)
        <div class="card border border-surface-container-highest rounded-md overflow-hidden shadow-sm hover:shadow-md hover:-translate-y-1 transition duration-200">

            <!-- Image -->
            <div class="relative overflow-hidden h-24 bg-surface-container">
                @if($gallery->image)
                    @if(str_starts_with($gallery->image, 'http'))
                        <img src="{{ $gallery->image }}" 
                             alt="{{ $gallery->title }}" 
                             class="w-full h-full object-cover hover:scale-105 transition duration-200">
                    @else
                        <img src="{{ Storage::url($gallery->image) }}" 
                             alt="{{ $gallery->title }}" 
                             class="w-full h-full object-cover hover:scale-105 transition duration-200">
                    @endif
                @else
                    <div class="w-full h-full flex items-center justify-center">
                        <span class="material-symbols-outlined text-2xl text-on-surface-variant">image</span>
                    </div>
                @endif
            </div>

            <!-- Content -->
            <div class="p-3">
                <h3 class="font-semibold text-sm truncate mb-1">
                    {{ $gallery->title }}
                </h3>

                <p class="text-xs text-on-surface-variant line-clamp-2 mb-2">
                    {{ $gallery->description }}
                </p>

                <!-- Info -->
                <div class="flex items-center justify-between mb-2">
                    <span class="text-[10px] text-on-surface-variant">
                        #{{ $gallery->sort_order }}
                    </span>

                    @if($gallery->is_active)
                        <span class="badge badge-success text-[10px] px-2 py-0">On</span>
                    @else
                        <span class="badge badge-neutral text-[10px] px-2 py-0">Off</span>
                    @endif
                </div>

                <!-- Actions -->
                <div class="flex gap-1">
                    <a href="{{ route('admin.gallery.edit', $gallery) }}" 
                       class="btn btn-xs btn-outline flex-1">
                        Edit
                    </a>

                    <form method="POST" action="{{ route('admin.gallery.destroy', $gallery) }}" 
                          class="flex-1"
                          onsubmit="return confirm('Yakin ingin menghapus?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-xs btn-outline btn-error w-full">
                            Hapus
                        </button>
                    </form>
                </div>
            </div>
        </div>
        @endforeach

    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $galleries->links() }}
    </div>

    @else

    <!-- Empty State -->
    <div class="text-center py-10">
        <span class="material-symbols-outlined text-5xl text-on-surface-variant mb-3 block">
            image_not_supported
        </span>
        <p class="text-on-surface-variant text-sm mb-4">
            Belum ada galeri.
        </p>
        <a href="{{ route('admin.gallery.create') }}" class="btn btn-primary btn-sm">
            <span class="material-symbols-outlined text-base">add</span> Buat
        </a>
    </div>

    @endif

</div>
@endsection