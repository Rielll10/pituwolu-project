@extends('admin.layouts.app')

@section('title', 'Edit Galeri | Admin Pituwolu')

@section('content')
<div class="container mx-auto px-4 py-8 max-w-2xl">
    <div class="mb-8">
        <a href="{{ route('admin.gallery.index') }}" class="text-primary hover:text-primary-dark flex items-center gap-2">
            <span class="material-symbols-outlined">arrow_back</span> Kembali
        </a>
    </div>

    <h1 class="text-3xl font-bold mb-8">Edit Galeri</h1>

    <form action="{{ route('admin.gallery.update', $gallery) }}" method="POST" enctype="multipart/form-data" class="card border border-surface-container-highest rounded-lg p-8">
        @csrf
        @method('PUT')

        <!-- Title -->
        <div class="form-group mb-6">
            <label for="title" class="block text-sm font-semibold mb-2">Judul</label>
            <input type="text" 
                   id="title" 
                   name="title" 
                   class="input input-bordered w-full @error('title') input-error @enderror"
                   value="{{ old('title', $gallery->title) }}"
                   required>
            @error('title')
            <span class="text-error text-sm mt-1">{{ $message }}</span>
            @enderror
        </div>

        <!-- Description -->
        <div class="form-group mb-6">
            <label for="description" class="block text-sm font-semibold mb-2">Deskripsi</label>
            <textarea id="description" 
                      name="description" 
                      class="textarea textarea-bordered w-full @error('description') textarea-error @enderror"
                      rows="3">{{ old('description', $gallery->description) }}</textarea>
            @error('description')
            <span class="text-error text-sm mt-1">{{ $message }}</span>
            @enderror
        </div>

        <!-- Current Image -->
        @if($gallery->image)
        <div class="form-group mb-6">
            <label class="block text-sm font-semibold mb-2">Gambar Saat Ini</label>
            <img src="{{ Storage::url($gallery->image) }}" 
                 alt="{{ $gallery->title }}" 
                 class="max-h-48 rounded-lg mb-2">
            <p class="text-xs text-on-surface-variant">Unggah gambar baru untuk mengganti</p>
        </div>
        @endif

        <!-- Image Upload -->
        <div class="form-group mb-6">
            <label for="image" class="block text-sm font-semibold mb-2">Gambar Baru (Opsional)</label>
            <div class="border-2 border-dashed border-surface-container-highest rounded-lg p-8 text-center cursor-pointer hover:border-primary transition"
                 onclick="document.getElementById('image').click()">
                <input type="file" 
                       id="image" 
                       name="image" 
                       accept="image/*" 
                       class="hidden @error('image') input-error @enderror"
                       onchange="previewImage(event)">
                <span class="material-symbols-outlined text-4xl text-on-surface-variant block mb-2">cloud_upload</span>
                <p class="text-on-surface-variant">Klik atau seret gambar di sini</p>
                <p class="text-xs text-on-surface-variant mt-2">JPG, PNG, GIF (Max 5MB)</p>
                <img id="preview" src="" alt="Preview" class="mt-4 max-h-48 mx-auto hidden">
            </div>
            @error('image')
            <span class="text-error text-sm mt-2 block">{{ $message }}</span>
            @enderror
        </div>

        <!-- Sort Order -->
        <div class="form-group mb-6">
            <label for="sort_order" class="block text-sm font-semibold mb-2">Urutan</label>
            <input type="number" 
                   id="sort_order" 
                   name="sort_order" 
                   class="input input-bordered w-full @error('sort_order') input-error @enderror"
                   value="{{ old('sort_order', $gallery->sort_order) }}"
                   min="1">
            @error('sort_order')
            <span class="text-error text-sm mt-1">{{ $message }}</span>
            @enderror
        </div>

        <!-- Active Status -->
        <div class="form-group mb-8">
            <label class="flex items-center gap-3">
                <input type="checkbox" 
                       name="is_active" 
                       value="1" 
                       class="checkbox"
                       {{ old('is_active', $gallery->is_active) ? 'checked' : '' }}>
                <span class="text-sm font-semibold">Aktifkan galeri ini</span>
            </label>
        </div>

        <!-- Submit Buttons -->
        <div class="flex gap-4">
            <a href="{{ route('admin.gallery.index') }}" class="btn btn-outline flex-1">
                Batal
            </a>
            <button type="submit" class="btn btn-primary flex-1">
                <span class="material-symbols-outlined">save</span> Simpan Perubahan
            </button>
        </div>
    </form>
</div>

<script>
function previewImage(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('preview');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.classList.remove('hidden');
        }
        reader.readAsDataURL(file);
    }
}
</script>
@endsection
